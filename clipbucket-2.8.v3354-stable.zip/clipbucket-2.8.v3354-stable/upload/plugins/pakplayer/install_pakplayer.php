<?php

$db->insert(tbl("config"),array("name","value"),array("pak_license",""));


?>