<?php
$db->Execute("DELETE FROM ".tbl("config")." WHERE name='pak_license' ");
?>