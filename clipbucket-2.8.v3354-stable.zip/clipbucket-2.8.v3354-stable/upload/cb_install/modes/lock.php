</div>

<div class="nav_des clearfix">
    <div class="cb_container">
    <h4 style="color:#fff">Installation is locked</h4>
    <p style="color:#fff; font-size:13px;">please create file "install.me" in folder /files/temp in order to install ClipBucket</p>
</div><!--cb_container-->
</div><!--nav_des-->

<div id="sub_container" >
<!--<h2>Installation is locked</h2>

please create file "install.me" in folder /files/temp in order to install ClipBucket-->