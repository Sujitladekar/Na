
-- Advertisement Placements

INSERT INTO `{tbl_prefix}ads_placements` (`placement_id`, `placement`, `placement_name`, `disable`) VALUES
(1, 'ad_160x600', 'Wide Skyscrapper 160 x 600', 'yes'),
(2, 'ad_468x60', 'Banner 468 x 60', 'yes'),
(3, 'ad_300x250', 'Medium Rectangle 300 x 250', 'yes'),
(4, 'ad_728x90', 'Leader Board 728 x 90', 'yes'),
(5, 'ad_120x600', 'Skyscrapper 120 x 600', 'yes');