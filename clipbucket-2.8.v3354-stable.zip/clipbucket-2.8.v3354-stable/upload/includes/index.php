<?php
header("Location: ../");
?>