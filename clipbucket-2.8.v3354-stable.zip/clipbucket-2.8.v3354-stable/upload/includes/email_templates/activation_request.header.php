
					<?php 
					$subj ="$username's  Account Activation" 
					?>
					