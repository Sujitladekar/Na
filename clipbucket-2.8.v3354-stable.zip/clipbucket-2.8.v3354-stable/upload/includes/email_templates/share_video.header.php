
					<?php 
					$subj ="$username Want To Share A Video With You" 
					?>
					