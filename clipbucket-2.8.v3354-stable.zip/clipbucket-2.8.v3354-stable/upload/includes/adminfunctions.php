<?php
/**
 **************************************************************************************************
 This source file is subject to the ClipBucket End-User License Agreement, available online at:
 http://www.opensource.org/licenses/attribution.php
 By using this software, you acknowledge having read this Agreement and agree to be bound thereby.
 **************************************************************************************************
 Copyright (c) 2007-2008 Clip-Bucket.com. All rights reserved.
 **************************************************************************************************
 **/

	//This Function is Used to Chech Admin Login
	
?>